> Here are some helper funtions
