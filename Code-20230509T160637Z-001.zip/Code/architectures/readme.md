> The internal architectures can be modified here
